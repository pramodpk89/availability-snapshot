package com.ppk.avlSnapshot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AvlSnapshotApplication {

	public static void main(String[] args) {
		SpringApplication.run(AvlSnapshotApplication.class, args);
	}

}
