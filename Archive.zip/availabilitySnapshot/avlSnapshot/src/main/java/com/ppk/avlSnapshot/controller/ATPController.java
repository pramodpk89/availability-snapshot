package com.ppk.avlSnapshot.controller;

import com.ppk.avlSnapshot.model.AvailabilityResponse;
import com.ppk.avlSnapshot.service.ATPService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("availabilityService/")
public class ATPController {
    @Autowired
    private ATPService atpService;

    @GetMapping("/getATP")
    public ResponseEntity<?> getATPForTS(
            @RequestParam("itemId") String itemId,
            @RequestParam("time") long time) {

        try {
            if (itemId == null || itemId.trim().isEmpty()) {
                return ResponseEntity.badRequest().body("Item ID is required.");
            }

            if (time <= 0) {
                return ResponseEntity.badRequest().body("Invalid time provided.");
            }

            AvailabilityResponse response = atpService.getATPForATimeStamp(itemId, time);
            if (response == null) {
                return ResponseEntity.notFound().build();
            }

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("An error occurred: " + e.getMessage());
        }
    }
}
