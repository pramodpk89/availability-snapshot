package com.ppk.avlSnapshot.controller;

import com.ppk.avlSnapshot.model.DemandAudit;
import com.ppk.avlSnapshot.service.DemandAuditService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("availabilityService/demandAudits")
public class DemandAuditController {

    @Autowired
    private DemandAuditService service;

    @GetMapping("/all")
    public List<DemandAudit> getAllDemandAudits() {
        return service.getAllDemandAudits();
    }

    // Get a single demand audit by ID
    @GetMapping("/{id}")
    public DemandAudit getDemandAuditById(@PathVariable String id) {
        return service.getDemandAuditById(id).orElse(null);
    }

    @GetMapping("orderNo/{orderNo}")
    public List<DemandAudit> getDemandsByOrderNo(@PathVariable String orderNo) {
        return service.getAllDemandsForOrderSorted(orderNo);
    }

    // Create a new demand audit
    @PostMapping
    public DemandAudit createDemandAudit(@RequestBody DemandAudit demandAudit) {
        return service.saveOrUpdateDemandAudit(demandAudit);
    }

    // Update an existing demand audit
    @PutMapping("/{id}")
    public DemandAudit updateDemandAudit(@PathVariable String id, @RequestBody DemandAudit demandAudit) {
        demandAudit.setId(id);
        return service.saveOrUpdateDemandAudit(demandAudit);
    }

    // Delete a demand audit
    @DeleteMapping("/{id}")
    public void deleteDemandAudit(@PathVariable String id) {
        service.deleteDemandAudit(id);
    }


}
