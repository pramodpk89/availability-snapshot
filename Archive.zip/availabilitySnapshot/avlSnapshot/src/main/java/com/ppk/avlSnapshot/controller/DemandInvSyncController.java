package com.ppk.avlSnapshot.controller;

import com.ppk.avlSnapshot.model.DemandInvSync;
import com.ppk.avlSnapshot.service.DemandInvSyncService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("availabilityService/demandInvSync")
public class DemandInvSyncController {

    @Autowired
    private DemandInvSyncService service;

    @GetMapping("/all")
    public List<DemandInvSync> getAllDemandAudits() {
        return service.getAllDemandInvSyncs();
    }

    @GetMapping("/{id}")
    public DemandInvSync getDemandInvSyncById(@PathVariable String id) {
        return service.getDemandInvSyncById(id).orElse(null);
    }

    @PostMapping
    public DemandInvSync createDemandInvSync(@RequestBody DemandInvSync demandInvSync) {
        return service.saveOrUpdateDemandInvSync(demandInvSync);
    }

    @PutMapping("/{id}")
    public DemandInvSync updateDemandInvSync(@PathVariable String id, @RequestBody DemandInvSync demandInvSync) {
        demandInvSync.setId(id);
        return service.saveOrUpdateDemandInvSync(demandInvSync);
    }

    @DeleteMapping("/{id}")
    public void deleteDemandInvSync(@PathVariable String id) {
        service.deleteDemandInvSync(id);
    }
}
