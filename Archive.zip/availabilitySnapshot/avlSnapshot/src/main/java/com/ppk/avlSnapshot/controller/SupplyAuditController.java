package com.ppk.avlSnapshot.controller;

import com.ppk.avlSnapshot.model.DemandAudit;
import com.ppk.avlSnapshot.model.SupplyAudit;
import com.ppk.avlSnapshot.service.DemandAuditService;
import com.ppk.avlSnapshot.service.SupplyAuditService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("availabilityService/supplyAudits")
public class SupplyAuditController {

    @Autowired
    private SupplyAuditService service;

    @GetMapping("/all")
    public List<SupplyAudit> getAllSupplyAudits() {
        return service.getAllsupplyAudits();
    }

    // Get a single demand audit by ID
    @GetMapping("/{id}")
    public SupplyAudit getSupplyAuditById(@PathVariable String id) {
        return service.getSupplyAuditById(id).orElse(null);
    }

    // Create a new demand audit
    @PostMapping
    public SupplyAudit createSupplyAudit(@RequestBody SupplyAudit supplyAudit) {
        return service.saveOrUpdateSupplyAudit(supplyAudit);
    }

    // Update an existing demand audit
    @PutMapping("/{id}")
    public SupplyAudit updateSupplyAudit(@PathVariable String id, @RequestBody SupplyAudit supplyAudit) {
        supplyAudit.setId(id);
        return service.saveOrUpdateSupplyAudit(supplyAudit);
    }

    // Delete a demand audit
    @DeleteMapping("/{id}")
    public void deleteSupplyAudit(@PathVariable String id) {
        service.deleteSupplyAudit(id);
    }
}
