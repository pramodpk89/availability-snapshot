package com.ppk.avlSnapshot.controller;

import com.ppk.avlSnapshot.model.SupplyInvSync;
import com.ppk.avlSnapshot.service.SupplyInvSyncService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("availabilityService/supplyInvSync")
public class SupplyInvSyncController {

    @Autowired
    private SupplyInvSyncService service;

    @GetMapping("/all")
    public List<SupplyInvSync> getAllSupplyAudits() {
        return service.getAllSupplyInvSyncs();
    }

    @GetMapping("/{id}")
    public SupplyInvSync getSupplyInvSyncById(@PathVariable String id) {
        return service.getDSupplyInvSyncById(id).orElse(null);
    }

    @PostMapping
    public SupplyInvSync createSupplyInvSync(@RequestBody SupplyInvSync supplyInvSync) {
        return service.saveOrUpdateSypplyInvSync(supplyInvSync);
    }

    @PutMapping("/{id}")
    public SupplyInvSync updateSupplyInvSync(@PathVariable String id, @RequestBody SupplyInvSync supplyInvSync) {
        supplyInvSync.setId(id);
        return service.saveOrUpdateSypplyInvSync(supplyInvSync);
    }

    @DeleteMapping("/{id}")
    public void deleteSupplyInvSync(@PathVariable String id) {
        service.deleteSupplyInvSync(id);
    }
}
