package com.ppk.avlSnapshot.model;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
public class AvailabilityResponse {
    String itemId;
    String uom;
    String productClass;
    String time;
    double supply;
    double demand;
    double availability;
}
