package com.ppk.avlSnapshot.repository;

import com.ppk.avlSnapshot.model.DemandAudit;
import com.ppk.avlSnapshot.model.DemandInvSync;
import com.ppk.avlSnapshot.model.SupplyInvSync;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;

public interface DemandInvSyncRepository extends MongoRepository<DemandInvSync, String> {
    @Query("{ 'data.Demand.createdTS': { $lte: ?0 }, 'data.Demand.ItemID': ?1 }")
    List<DemandInvSync> findLatestByCreatedTsAndItemId(long requestTs, String itemId, Sort sort);
}
