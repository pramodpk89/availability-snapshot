package com.ppk.avlSnapshot.repository;

import com.ppk.avlSnapshot.model.DemandAudit;
import com.ppk.avlSnapshot.model.SupplyAudit;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;

public interface SupplyAuditRepository extends MongoRepository<SupplyAudit, String> {
    @Query("{ 'data.Supply.createdTS': { $lte: ?0 }, 'data.Supply.ItemID': ?1 }")
    List<SupplyAudit> findByCreatedTsBeforeAndItemId(long requestTs, String itemId);
}
