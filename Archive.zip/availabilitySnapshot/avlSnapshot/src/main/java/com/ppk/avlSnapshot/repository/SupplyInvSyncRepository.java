package com.ppk.avlSnapshot.repository;

import com.ppk.avlSnapshot.model.DemandInvSync;
import com.ppk.avlSnapshot.model.SupplyInvSync;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;
import java.util.Optional;

public interface SupplyInvSyncRepository extends MongoRepository<SupplyInvSync, String> {
    @Query("{ 'data.Supply.createdTS': { $lte: ?0 }, 'data.Supply.ItemID': ?1 }")
    List<SupplyInvSync> findLatestByCreatedTsAndItemId(long requestTs, String itemId, Sort sort);
}
