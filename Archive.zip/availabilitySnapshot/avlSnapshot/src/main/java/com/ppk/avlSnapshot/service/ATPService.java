package com.ppk.avlSnapshot.service;

import com.ppk.avlSnapshot.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ATPService {
    @Autowired
    private DemandAuditService demandService;

    @Autowired
    private SupplyAuditService supplyService;
    @Autowired
    private SupplyInvSyncService supplyInvSyncService;

    @Autowired
    private DemandInvSyncService demandInvSyncService;
    public AvailabilityResponse getATPForATimeStamp(String itemId,long time){

        double absoluteSupply=getAbsoluteSupply(supplyInvSyncService.findLatestSupplySyncBeforeTimestampByItemId(time,itemId));
        double absoluteDemand=getAbsoluteDemand(demandInvSyncService.findLatestDemandSyncBeforeTimestampByItemId(time,itemId));

        double deltaDemands=calculateTotalDemandChanges(demandService.findDemandsBeforeTimestampAndByItemId(time,itemId));
        double deltaSupplies=calculateTotalSupplyChanges(supplyService.findSuppliesBeforeTimestampAndByItemId(time,itemId));

        double availableToPromise=(absoluteSupply+deltaSupplies)-(absoluteDemand+deltaDemands);
        return new AvailabilityResponse(itemId,"","",convertEpochToFormattedDateTime(time),absoluteSupply+deltaSupplies,absoluteDemand+deltaDemands,availableToPromise);
    }

    public static String convertEpochToFormattedDateTime(long epochSeconds) {
        LocalDateTime dateTime = LocalDateTime.ofInstant(Instant.ofEpochSecond(epochSeconds), ZoneId.systemDefault());
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy hh:mm a");
        return dateTime.format(formatter);
    }

    private double getAbsoluteDemand(DemandInvSync demandSync) {
        try {
            HashMap<String, String> supplyQty = (HashMap<String, String>) demandSync.getData().get("Supply");
            return Double.parseDouble(supplyQty.get("Quantity"));
        }
        catch (Exception e){
            return 0;
        }
    }

    private double getAbsoluteSupply(SupplyInvSync supplySync) {
        try {
            HashMap<String, String> supplyQty = (HashMap<String, String>) supplySync.getData().get("Supply");
            return Double.parseDouble(supplyQty.get("Quantity"));
        }
        catch (Exception e){
            return 0;
        }
    }

    public double calculateTotalDemandChanges(List<DemandAudit> demandChanges) {
        return demandChanges.stream()
                .map(DemandAudit::getData)
                .filter(data -> data != null && data.containsKey("Demand"))
                .map(data -> (Map<String, Object>) data.get("Demand"))
                .filter(demandData -> demandData != null && demandData.containsKey("Quantity"))
                .map(demandData -> parseQuantity((String) demandData.get("Quantity")))
                .reduce(0.0, Double::sum); // Summing up all the quantities
    }

    public double calculateTotalSupplyChanges(List<SupplyAudit> supplyChanges) {
        return supplyChanges.stream()
                .map(SupplyAudit::getData)
                .filter(data -> data != null && data.containsKey("Supply"))
                .map(data -> (Map<String, Object>) data.get("Supply"))
                .filter(demandData -> demandData != null && demandData.containsKey("Quantity"))
                .map(demandData -> parseQuantity((String) demandData.get("Quantity")))
                .reduce(0.0, Double::sum); // Summing up all the quantities
    }
    private Double parseQuantity(String quantityStr) {
        try {
            return Double.parseDouble(quantityStr);
        } catch (NumberFormatException e) {
            System.err.println("Invalid quantity format: " + quantityStr);
            return 0.0;
        }
    }
}
