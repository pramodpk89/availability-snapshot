package com.ppk.avlSnapshot.service;

import com.ppk.avlSnapshot.model.DemandAudit;
import com.ppk.avlSnapshot.repository.DemandAuditRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class DemandAuditService {
    @Autowired
    private DemandAuditRepository repository;

    // Fetch all demand audits
    public List<DemandAudit> getAllDemandAudits() {
        return repository.findAll();
    }

    // Fetch a single demand audit by ID
    public Optional<DemandAudit> getDemandAuditById(String id) {
        return repository.findById(id);
    }

    // Create or update a demand audit
    public DemandAudit saveOrUpdateDemandAudit(DemandAudit demandAudit) {
        return repository.save(demandAudit);
    }

    // Delete a demand audit
    public void deleteDemandAudit(String id) {
        repository.deleteById(id);
    }

    public List<DemandAudit> findDemandsBeforeTimestampAndByItemId(long requestTs, String itemId) {
        return repository.findByCreatedTsBeforeAndItemId(requestTs, itemId);
    }

    public List<DemandAudit> getAllDemandsForOrderSorted(String orderNo) {
        return repository.findAllDemandsForOrderNo(orderNo,Sort.by(Sort.Direction.ASC, "data.Demand.createdTS"));
    }
}
