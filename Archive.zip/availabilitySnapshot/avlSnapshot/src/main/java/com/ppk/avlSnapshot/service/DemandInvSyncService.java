package com.ppk.avlSnapshot.service;

import com.ppk.avlSnapshot.model.DemandInvSync;
import com.ppk.avlSnapshot.model.SupplyInvSync;
import com.ppk.avlSnapshot.repository.DemandInvSyncRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DemandInvSyncService {
    @Autowired
    private DemandInvSyncRepository repository;

    public List<DemandInvSync> getAllDemandInvSyncs() {
        return repository.findAll();
    }

    public Optional<DemandInvSync> getDemandInvSyncById(String id) {
        return repository.findById(id);
    }

    public DemandInvSync saveOrUpdateDemandInvSync(DemandInvSync demandInvSync) {
        return repository.save(demandInvSync);
    }

    public void deleteDemandInvSync(String id) {
        repository.deleteById(id);
    }

    public DemandInvSync findLatestDemandSyncBeforeTimestampByItemId(long requestTs, String itemId) {
        List<DemandInvSync> results = repository.findLatestByCreatedTsAndItemId(
                requestTs,
                itemId,
                Sort.by(Sort.Direction.DESC, "data.Supply.createdTS")
        );

        if (!results.isEmpty()) {
            return results.get(0);
        }
        return null;
    }
}
