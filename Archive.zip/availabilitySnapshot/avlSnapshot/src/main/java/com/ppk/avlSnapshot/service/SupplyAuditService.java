package com.ppk.avlSnapshot.service;

import com.ppk.avlSnapshot.model.DemandAudit;
import com.ppk.avlSnapshot.model.SupplyAudit;
import com.ppk.avlSnapshot.repository.SupplyAuditRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SupplyAuditService {
    @Autowired
    private SupplyAuditRepository repository;

    // Fetch all supply audits
    public List<SupplyAudit> getAllsupplyAudits() {
        return repository.findAll();
    }

    // Fetch a single supply audit by ID
    public Optional<SupplyAudit> getSupplyAuditById(String id) {
        return repository.findById(id);
    }

    // Create or update a supply audit
    public SupplyAudit saveOrUpdateSupplyAudit(SupplyAudit supplyAudit) {
        return repository.save(supplyAudit);
    }

    // Delete a supply audit
    public void deleteSupplyAudit(String id) {
        repository.deleteById(id);
    }

    public List<SupplyAudit> findSuppliesBeforeTimestampAndByItemId(long requestTs, String itemId) {
        return repository.findByCreatedTsBeforeAndItemId(requestTs, itemId);
    }
}
