package com.ppk.avlSnapshot.service;

import com.ppk.avlSnapshot.model.SupplyInvSync;
import com.ppk.avlSnapshot.repository.SupplyInvSyncRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SupplyInvSyncService {
    @Autowired
    private SupplyInvSyncRepository repository;

    public List<SupplyInvSync> getAllSupplyInvSyncs() {
        return repository.findAll();
    }

    public Optional<SupplyInvSync> getDSupplyInvSyncById(String id) {
        return repository.findById(id);
    }

    public SupplyInvSync saveOrUpdateSypplyInvSync(SupplyInvSync supplyInvSync) {
        return repository.save(supplyInvSync);
    }

    public void deleteSupplyInvSync(String id) {
        repository.deleteById(id);
    }

    public SupplyInvSync findLatestSupplySyncBeforeTimestampByItemId(long requestTs, String itemId) {
        List<SupplyInvSync> results = repository.findLatestByCreatedTsAndItemId(
                requestTs,
                itemId,
                Sort.by(Sort.Direction.DESC, "data.Supply.createdTS")
        );

        if (!results.isEmpty()) {
            return results.get(0);
        }
        return null;
    }
}
